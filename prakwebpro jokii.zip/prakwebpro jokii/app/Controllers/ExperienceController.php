<?php

namespace App\Controllers;

class ExperienceController extends BaseController
{
    public function index(): string
    {
        return view('experience');
    }
}
