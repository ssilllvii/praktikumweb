<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <head>
        <h1>My web</h1>
    </head>
    <nav>
        <ul>
            <li><a href="/">Home</a></li>
            <li><a href="/profile">Profile</a></li>
            <li><a href="/experience">experience</a></li>
        </ul>
    </nav>
    <main>
        <?= $this->renderSection('content') ?>
    </main>
    <footer>
        <p>Copyright@</p>
    </footer>
</body>
</html>