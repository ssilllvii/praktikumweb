<?= $this->extend('layout') ?>

<?= $this->section('content') ?>
<h2>My Experience</h2>
<ul>
    <li>mahasiswa di teknik informatika unissula</li>
    <li>menjadi tenaga pengajar di ponpes Attohiriyah</li>
    <li>menjadi agen haji dan umrah di al muna trafel</li>
</ul>
<?= $this->endSection() ?>