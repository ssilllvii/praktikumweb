<?= $this->extend('layout') ?>

<?= $this->section('content') ?>
<h2>Profil</h2>
<?= $this->endSection() ?>
