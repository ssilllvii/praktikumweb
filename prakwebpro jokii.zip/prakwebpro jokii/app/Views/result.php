<!DOCTYPE html>
<html>
<head>
    <title>Data Hasil</title>
</head>
<body>
    <h1>Data yang Diterima</h1>
    <p>Nama: <?= $nama ?></p>
    <p>NIM: <?= $nim ?></p>
    <p>Kelas: <?= $kelas ?></p>
    <p>Mata Kuliah: <?= $mata_kuliah ?></p>
    <p>Dosen Pengampu: <?= $dosen_pengampu ?></p>
    <p>Asisten Praktikum: <?= $asisten_praktikum ?></p>
</body>
</html>
